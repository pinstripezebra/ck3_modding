version="1.0.0"
tags={
	"Gameplay"
}
name="WizardMod"
supported_version="1.12.*"
